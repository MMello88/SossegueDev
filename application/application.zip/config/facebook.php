<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');

	$config['appID']     = '148589512211468';
	$confif['appSecret'] = '2cfb0e939ea0e4469be6a91e19fc305d';

	?>