<div class="section-title section-bg section-bg-img section-bg-img_mod-a">
    <div class="container">
        <div class="row">
            <div class="col-xs-12">
                <div class="section__inner">
                    <h1 class="ui-title-page">Cadastro confirmado com sucesso!</h1>
                    <h2 class="ui-title-page" style="font-size: 20px"><a style="color: #fff" href="<?php echo base_url('restrita/home') ?>"><span class="color_primary">Clique aqui</span></a> para visualizar suas informações.</h2>
                </div>
            </div>
        </div>
    </div>
</div>
<?php include_once("analyticstracking.php") ?>
