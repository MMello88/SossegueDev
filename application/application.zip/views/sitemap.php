<?xml version="1.0" encoding="UTF-8"?> 
<sitemapindex xmlns="http://www.sitemaps.org/schemas/sitemap/0.9"> 

<sitemap> 
  <loc>http://www.sossegue.com.br</loc> 
  <lastmod>2017-03-09</lastmod> 
</sitemap> 

<sitemap> 
  <loc>http://www.sossegue.com.br/pedidos/ribeirao-preto</loc> 
  <lastmod>2017-03-09</lastmod> 
</sitemap> 

<sitemap> 
  <loc>http://www.sossegue.com.br/eletricista/ribeirao-preto</loc> 
  <lastmod>2017-03-09</lastmod> 
</sitemap> 

<sitemap> 
  <loc>http://www.sossegue.com.br/encanador/ribeirao-preto</loc> 
  <lastmod>2017-03-09</lastmod> 
</sitemap> 

<sitemap> 
  <loc>http://www.sossegue.com.br/faq</loc> 
  <lastmod>2017-03-09</lastmod> 
</sitemap> 

<sitemap> 
  <loc>http://www.sossegue.com.br/gesso/ribeirao-preto</loc> 
  <lastmod>2017-03-09</lastmod> 
</sitemap> 

<sitemap> 
  <loc>http://www.sossegue.com.br/jardinagem/ribeirao-preto</loc> 
  <lastmod>2017-03-09</lastmod> 
</sitemap> 

<sitemap> 
  <loc>http://www.sossegue.com.br/marceneiro/ribeirao-preto</loc> 
  <lastmod>2017-03-09</lastmod> 
</sitemap> 

<sitemap> 
  <loc>http://www.sossegue.com.br/maridodealuguel/ribeirao-preto</loc> 
  <lastmod>2017-03-09</lastmod> 
</sitemap> 

<sitemap> 
  <loc>http://www.sossegue.com.br/montador-de-moveis/ribeirao-preto</loc> 
  <lastmod>2017-03-09</lastmod> 
</sitemap> 

<sitemap> 
  <loc>http://www.sossegue.com.br/pintor/ribeirao-preto</loc> 
  <lastmod>2017-03-09</lastmod> 
</sitemap> 

<sitemap> 
  <loc>http://www.sossegue.com.br/sobre/quem-somos</loc>
  <lastmod>2017-03-09</lastmod> 
</sitemap>

<sitemap> 
  <loc>http://www.sossegue.com.br/sobre/termos-e-condicoes</loc>
  <lastmod>2017-03-09</lastmod> 
</sitemap> 

<sitemap> 
  <loc>http://www.sossegue.com.br/cadastro</loc>
  <lastmod>2017-03-09</lastmod> 
</sitemap>

</sitemapindex> 