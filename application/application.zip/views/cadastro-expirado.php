<div class="section-title section-bg section-bg-img section-bg-img_mod-a">
	<div class="container">
		<div class="row">
			<div class="col-xs-12">
				<div class="section__inner">
					<h1 class="ui-title-page">Prazo de confirmação do cadastro expirado!</h1>
					<h2 class="ui-title-page" style="font-size: 20px"><a style="color: #fff" href="<?php echo base_url('cadastro/reenviaLink')?>"><span class="color_primary">Clique aqui</span></a> para reenviar o link de confirmação para seu email cadastrado.</h2>
				</div>
			</div>
		</div>
	</div>
</div>
<?php include_once("analyticstracking.php") ?>
