<meta name="robots" content="noindex, nofollow">
<meta name=viewport content="width=device-width, initial-scale=1">
<div class="section-title section-bg section-bg-img section-bg-img_mod-a">
	<div class="container">
		<div class="row">
			<div class="col-xs-12">
				<div class="section__inner">
					<h1 class="ui-title-page">Prezado(a) <?php echo $this->session->userdata('nome'); ?>, seu pedido de contratação foi realizado com sucesso!</h1>
					<h3 class="ui-title-page" style="font-size: 24px"> Em breve entraremos em contato para que você aprove a contratação do serviço.</h3>     
					<h5 class="ui-title-page" style="font-size: 20px"><a style="color: #fff" href="<?php echo base_url('home'); ?>"><span class="color_primary">Clique aqui</span></a> para voltar para a página inicial</h5>
				</div>
			</div>
		</div>
	</div>
</div>
<?php include_once("analyticstracking.php") ?>
