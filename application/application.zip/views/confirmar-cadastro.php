<div class="section-title section-bg section-bg-img section-bg-img_mod-a">
	<div class="container">
		<div class="row">
			<div class="col-xs-12">
				<div class="section__inner">
					<h1 class="ui-title-page">Cadastro efetuado com sucesso!</h1>
					<h2 class="ui-title-page" style="font-size: 20px">Enviamos um email para <span class="color_primary"><?php echo $this->session->userdata('email'); ?></span>, acesse seus email e clique no link enviado para validar seu cadastro!</h2>
				</div>
			</div>
		</div>
	</div>
</div>
<?php include_once("analyticstracking.php") ?>
