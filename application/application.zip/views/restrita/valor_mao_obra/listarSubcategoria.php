<?php include_once(APPPATH . 'views/restrita/includes/header.php'); ?>

<div class="alert alert-danger alert-dismissible" id="message-danger" style="display: none;" role="alert">
  <button type="button" class="close" data-dismiss="alert" aria-label="Close">
    <span aria-hidden="true">&times;</span>
  </button>
  <p id="msgError"></p>
</div>

<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">

<h5> Quais são as categorias que você presta serviço? (Marque quantas quiser)</h5>
<br><br>

<?php    
	echo $listaSubcategorias;
?>

</div>
</div>
</div>
</div>
</div>
</div>
</div>
</section>


