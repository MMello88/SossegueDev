<?php include_once(APPPATH . "views/restrita/includes/header.php"); ?>

<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">

<?php echo form_open("restrita/prof/next/pergunta", array("id" => "formsubcatgPergunta")); ?>
<div class="w3-container">
  <div class="w3-panel w3-border w3-light-grey w3-round-large">
    <p>AGORA VAMOS INICIAR O PREENCHIMENTO DOS VALORES DA SUA MÃO DE OBRA. LEMBRANDO QUE NÃO DEVE COLOCAR O VALOR COM MATERIAL JUNTO, PODE DEIXAR QUE ISSO DEPOIS A SOSSEGUE IRÁ CUIDAR. </p>
    <p>VOCÊ TEM A OPÇÃO DE UM PREENCHIMENTO AUTOMÁTICO E MUITO MAIS RÁPIDO, NÃO SE PREOCUPE, CASO OS VALORES AUTOMÁTICOS NÃO SEJAM COMPATÍVEIS COM OS QUE VOCÊ PRATICA VOCÊ PODE AUTERÁ-LOS A QUALQUER MOMENTO.</p>
    <p>VOCÊ TEM A OPÇÃO DE UM PREENCHIMENTO MANUAL TAMBÉM, ESSE PROCESSO PODE DEMORAR UM POUCO PARA SER FINALIZADO, MAS VAMOS LÁ!! VOCÊ TERÁ SEUS VALORES EXATOS!!</p>
    <p>AO ACABAR O PREENCHIMENTO VOCÊ RECEBERÁ CONSTANTEMENTE SERVIÇOS SEM O FAMOSO "MIMIMI"..rsss.. DE SEUS CLIENTES, OU SEJA, NÃO HÁ MAIS PECHINCHA COM ELES. </p>
    <p>O PREOCESSO É MUITO MAIS CERTEIRO, UMA VEZ QUE O CLIENTE ESCOLHE SEU SERVIÇO TOTALMENTE ONLINE EM NOSSA PLATAFORMA. DEPOIS DE ESCOLHIDOS, NÓS SÓ IREMOS LIGAR PARA AGENDAR A MELHOR DATA E HORÁRIO.</p>
    <p>VOCÊ AINDA PODERÁ VISUALIZAR EM SEU ADMINISTRATIVO TODOS OS SERVIÇOS REALIZADOS E QUANTO GANHOU COM CADA UM DELES, ISSO NÃO É DEMAIS?!?!
</p>
  </div>
</div>

<div class="w3-bar">
  <button class="w3-button w3-red" id="btnVoltarPergunta">Voltar</button>
  <button class="w3-button w3-black">Terminar Mais Tarde</button>
  <button type="submit" class="w3-button w3-yellow">Próxima</button>
</div>
</form>


</div>
</div>
</div>
</div>
</div>
</div>
</div>
</section>
