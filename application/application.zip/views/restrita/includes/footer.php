                            <div class="modal fade" id="modalDelete" tabindex="-1" role="dialog" style="">
                              <div class="modal-dialog modal-sm" role="document">
                                <div class="modal-content">
                                  <div class="modal-header">
                                    <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                                    <h4 class="modal-title">Deseja realmente deletar?</h4>
                                  </div>
                                  <div class="modal-body">
                                    <button type="button" class="btn btn-info" data-dismiss="modal">Não</button>
                                    <button type="button" class="btn btn-primary" id="confDelete" data-dismiss="modal">Sim</button>
                                  </div>
                                </div>
                              </div>
                            </div>
                            <div class="modal fade" id="imageModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
                                <div class="modal-dialog">
                                    <div class="modal-content">
                                        <div class="modal-header">
                                            <button type="button" class="close" data-dismiss="modal"><span aria-hidden="true">&times;</span><span class="sr-only">Close</span></button>
                                        </div>
                                        <div class="modal-body">
                                            <img src="" id="imagepreview" style="display:block; margin: 0 auto; width: 100%;">
                                        </div>
                                        <div class="modal-footer">
                                            <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                                        </div>
                                    </div>
                                </div>
                            </div>
                    
                    </div>
            
</section>
