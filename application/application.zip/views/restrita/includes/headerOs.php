<style>
div.formatacao{
	width: 1210px;
	margin: 0px -20px;
  
}

div.formatacao2{
    margin: -70px 10px 0px 0px;
    
}
</style>

<section class="section_mod-d border-top">
            <div class="container formatacao2">
                <div class="row">
                    <?php include_once('menuOs.php'); ?>
                    <div class="col-sm-10 col-md-10">
                        <div class="well formatacao">
                            <div class="table-responsive">