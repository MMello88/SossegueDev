<?php include_once(APPPATH . 'views/restrita/includes/header.php'); ?>

<?php echo form_open_multipart('restrita/dados/pedido', array('id' => 'formCadastro')); ?>

<?php echo form_close(); ?>
<?php include_once(APPPATH . 'views/restrita/includes/footer.php'); ?>
