<meta name="robots" content="noindex, nofollow">
<div class="container">
<div class="row tipo-cadastro">
		<div class="titulo-tipo" align="center">
			<h1 style="color: #DAA520;"> Faça seu orçamento!</h1>
			<h2 style="color: #DAA520;">Escolha a forma que mais se adequa a sua necessidade!</h2>
			<br /><br /><br />
			<div class="row">
				<div class="form-group col-sm-6">    
            		<h1>ESCOLHA UM SERVIÇO E DATA</h1>
            		<h6>AGUARDE QUE ENTRAREMOS EM CONTATO</h6><br />
   					<a href="<?php echo base_url('agendamentos/agendar'); ?>" class="btn btn-default btn-second btn-effect btn-banner-b">Contrate um Serviço Agora</a>
				</div>
				<div class="form-group col-sm-6">    
    				<h1>RECEBA 3 ORÇAMENTOS</h1>
    				<h6>PROCURAMOS OS MELHORES PROFISSIONAIS DA REGIÃO</h6>
    				<br />
   					<a href="<?php echo base_url('pedidos/realizar'); ?>" class="btn btn-default btn-second btn-effect btn-banner-b">Pedir Orçamento</a>
				</div>

			</div>
		</div>
	</div>
</div>



