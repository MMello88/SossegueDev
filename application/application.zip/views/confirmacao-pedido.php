<!-- Google Code for Finalizado Conversion Page -->
<script type="text/javascript">
/*<![CDATA[*/
var google_conversion_id = 928512372;
var google_conversion_language = "en";
var google_conversion_format = "3";
var google_conversion_color = "ffffff";
var google_conversion_label = "28xQCMzEyW4Q9PLfugM";
var google_remarketing_only = false;
/*]]>*/
</script>
<script type="text/javascript" src="http://www.googleadservices.com/pagead/conversion.js">
</script>
<noscript>
<div style="display:inline;">
<img height="1" width="1" style="border-style:none;" alt="" src="http://www.googleadservices.com/pagead/conversion/928512372/?label=28xQCMzEyW4Q9PLfugM&amp;guid=ON&amp;script=0"/>
</div>
</noscript>

<section>
    
<div class="section-title section-bg section-bg-img section-bg-img_mod-a">
	<div class="container">
		<div class="row">
			<div class="col-xs-12">
				<div class="section__inner">
					<h1 class="ui-title-page">Prezado(a) <?php echo $this->session->userdata('nome'); ?>, seu pedido foi realizado com sucesso!</h1>
					<h3 class="ui-title-page" style="font-size: 24px"> Em breve retornaremos com até 3 orçamentos para você.</h3>     
					<h5 class="ui-title-page" style="font-size: 20px"><a style="color: #fff" href="<?php echo base_url('home'); ?>"><span class="color_primary">Clique aqui</span></a> para voltar para a página inicial</h5>
				</div>
			</div>
		</div>
	</div>
</div>
    
</section>
    <?php include_once("analyticstracking.php") ?>